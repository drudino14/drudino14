    document.onreadystatechange = function() {
    if (document.readyState !== "complete") {
    document.querySelector(
    "body").style.visibility = "hidden";
    document.querySelector(
    "#loader").style.visibility = "visible";
    } else {
    document.querySelector(
    "#loader").style.display = "none";
    document.querySelector(
    "body").style.visibility = "visible";
    }
    };

    window.onscroll = function() {scrollFunction()};

    function scrollFunction() {
    if (document.body.scrollTop > 50 || document.documentElement.scrollTop > 50) {
    document.getElementById("headingBar").style.fontSize = "70%";
    document.getElementById("logo").style.width = "13%";
    document.getElementById("search").style.marginTop = "3%";
    } else {
    document.getElementById("headingBar").style.fontSize = "100%";
    document.getElementById("logo").style.width = "15%";
    document.getElementById("search").style.marginTop = "5%";
    }
    }  

    function topFunction() {
    document.body.scrollTop = 0;
    document.documentElement.scrollTop = 0;
    }

    function disFunction() {
    confirm("Allow this website to send your personal details");
    }